"""
02_process_coverage.py  —  FCC mobile coverage -> covered_share per FL county.

Reads the FCC "Mobile Broadband Summary by Geography Type" file from data/raw/,
filters to Florida counties, and writes one coverage value per county.

Outputs: data/processed/coverage_by_county.csv  (GEO_ID, covered_share)

>>> This is a SKELETON. The exact column names depend on the mobile summary file
>>> you download — fill the TODOs after inspecting its header. The fixed-broadband
>>> analog used: geography_type, geography_id, geography_desc, technology,
>>> biz_res, speed_* (coverage as a 0..1 fraction). The mobile file is structured
>>> the same way, with technology values like 4G LTE / 5G-NR.
"""
import pandas as pd

RAW = "data/raw/bdc_us_mobile_broadband_summary_by_geography_XXXX.csv"  # TODO: real filename

# TODO: choose the coverage definition (decide + log it in RESEARCH_LOG.md)
TECHNOLOGY = "5G-NR"        # or "4G LTE"; run both as a sensitivity check
COVERAGE_COL = "TODO"      # the speed/coverage column holding the 0..1 covered share


def main():
    df = pd.read_csv(RAW, dtype=str)

    # --- inspect first ---
    # print(df.columns.tolist()); print(df["technology"].unique()); return

    # Filter to Florida COUNTY rows (FIPS 12). Do NOT match on the name "Florida"
    # — that catches Florida Municipio in Puerto Rico (FIPS 72).
    is_county = df["geography_type"] == "County"
    is_fl = df["geography_id"].str.startswith("12")          # TODO: confirm id width/format
    is_tech = df["technology"] == TECHNOLOGY
    sub = df[is_county & is_fl & is_tech].copy()

    sub[COVERAGE_COL] = pd.to_numeric(sub[COVERAGE_COL], errors="coerce")
    sub["GEO_ID"] = "0500000US" + sub["geography_id"]        # TODO: align to 5-digit county FIPS
    sub = sub.rename(columns={COVERAGE_COL: "covered_share"})

    out = sub[["GEO_ID", "covered_share"]].drop_duplicates("GEO_ID")
    assert len(out) == 67, f"expected 67 counties, got {len(out)} — check the filter"

    path = "data/processed/coverage_by_county.csv"
    out.to_csv(path, index=False)
    print(f"wrote {path}  ({len(out)} counties)")


if __name__ == "__main__":
    main()
