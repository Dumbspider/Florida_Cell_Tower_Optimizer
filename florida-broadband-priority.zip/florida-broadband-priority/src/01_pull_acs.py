"""
01_pull_acs.py  —  Pull ACS demographic features for Florida's 67 counties.

Outputs: data/processed/acs_features.csv  (keyed by GEO_ID, NAME)

Detailed (B-) and Subject (S-) tables live on different API endpoints, so this
makes one call to each and merges on GEO_ID.
"""
import os
import pandas as pd
import requests

YEAR = 2023            # ACS 5-year vintage (2019-2023)
STATE_FIPS = "12"      # Florida
API_KEY = os.environ.get("CENSUS_API_KEY")   # free: api.census.gov/data/key_signup.html

DETAILED = f"https://api.census.gov/data/{YEAR}/acs/acs5"
SUBJECT = f"https://api.census.gov/data/{YEAR}/acs/acs5/subject"

# NOTE: subject-table column numbers can shift between vintages. If a column looks
# wrong, verify against {SUBJECT}/variables.html for your YEAR.
DETAILED_VARS = ["B19013_001E",   # median household income
                 "B01002_001E",   # median age
                 "B01003_001E",   # total population
                 "B25003_001E",   # occupied housing units (renter denominator)
                 "B25003_003E"]   # renter-occupied units
SUBJECT_VARS = ["S1701_C03_001E",  # poverty rate
                "S1501_C02_015E",  # % bachelor's degree or higher
                "S2301_C04_001E"]  # unemployment rate


def fetch(base, varlist):
    params = {"get": "NAME," + ",".join(varlist),
              "for": "county:*", "in": f"state:{STATE_FIPS}"}
    if API_KEY:
        params["key"] = API_KEY
    r = requests.get(base, params=params, timeout=30)
    r.raise_for_status()
    rows = r.json()
    df = pd.DataFrame(rows[1:], columns=rows[0])
    df["GEO_ID"] = "0500000US" + df["state"] + df["county"]   # matches your other files
    for v in varlist:
        df[v] = pd.to_numeric(df[v], errors="coerce")
    return df.drop(columns=["state", "county"])


def main():
    det = fetch(DETAILED, DETAILED_VARS)
    sub = fetch(SUBJECT, SUBJECT_VARS)
    df = det.merge(sub.drop(columns="NAME"), on="GEO_ID")

    df["Pct Renter Occupied"] = df["B25003_003E"] / df["B25003_001E"] * 100
    df = df.rename(columns={
        "B19013_001E": "Median Household Income",
        "B01002_001E": "Median Age",
        "B01003_001E": "Population",
        "S1701_C03_001E": "Poverty Rate",
        "S1501_C02_015E": "Pct Bachelors Or Higher",
        "S2301_C04_001E": "Unemployment Rate",
    })

    cols = ["GEO_ID", "NAME", "Population", "Median Household Income", "Poverty Rate",
            "Median Age", "Pct Bachelors Or Higher", "Unemployment Rate",
            "Pct Renter Occupied"]
    df = df[cols].sort_values("NAME").reset_index(drop=True)

    out = "data/processed/acs_features.csv"
    df.to_csv(out, index=False)
    print(f"wrote {out}  ({len(df)} counties)")
    print(df.head().to_string(index=False))


if __name__ == "__main__":
    main()
