"""
04_explore_importance.py  —  What county characteristics drive the coverage gap?

Supporting analysis for the paper (NOT the prioritization itself). The dependent
variable is the observed mobile coverage gap; predictors are ACS demographics.
This answers "does the gap fall hardest on poorer/older/more-rural counties?" —
which motivates the equity weighting in the index.

Uses permutation importance (more honest than Gini with correlated features and
small n) and prints the correlation matrix so collinearity is visible.

Caveats baked in: n=67 is small, so importances are noisy; income & poverty are
collinear (one economic axis); results are associational, not causal.
"""
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.inspection import permutation_importance
from sklearn.model_selection import train_test_split

FEATURES = ["Median Household Income", "Poverty Rate", "Median Age",
            "Pct Bachelors Or Higher", "Unemployment Rate", "Pct Renter Occupied"]


def main():
    acs = pd.read_csv("data/processed/acs_features.csv")
    cov = pd.read_csv("data/processed/coverage_by_county.csv")
    df = acs.merge(cov, on="GEO_ID", how="inner").dropna(subset=FEATURES + ["covered_share"])

    # Dependent variable = coverage gap (observed). NOT subscription rate.
    df["coverage_gap"] = 1 - df["covered_share"]
    X, y = df[FEATURES], df["coverage_gap"]

    print("Correlation among predictors (watch income vs poverty):")
    print(X.corr().round(2).to_string(), "\n")

    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.3, random_state=0)
    rf = RandomForestRegressor(n_estimators=500, random_state=0).fit(X_tr, y_tr)
    print(f"Held-out R^2: {rf.score(X_te, y_te):.2f}  (expect modest with n={len(df)})\n")

    perm = permutation_importance(rf, X_te, y_te, n_repeats=50, random_state=0)
    imp = (pd.DataFrame({"feature": FEATURES,
                         "importance": perm.importances_mean,
                         "std": perm.importances_std})
           .sort_values("importance", ascending=False))
    print("Permutation importance (drop in performance when feature is shuffled):")
    print(imp.to_string(index=False))


if __name__ == "__main__":
    main()
