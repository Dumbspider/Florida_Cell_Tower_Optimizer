"""
03_build_index.py  —  Merge features + coverage, compute priority score, rank.

Outputs:
  outputs/tables/priority_ranking.csv   final ranking at default weights
  outputs/tables/weight_sensitivity.csv top-10 stability across weight choices
"""
import pandas as pd

W_GAP, W_NEED = 0.7, 0.3   # default weights — assumptions, swept below


def minmax(s):
    return (s - s.min()) / (s.max() - s.min())


def score(df, w_gap, w_need):
    df = df.copy()
    df["coverage_gap"] = 1 - df["covered_share"]
    df["unserved_people"] = df["coverage_gap"] * df["Population"]
    df["gap_score"] = minmax(df["unserved_people"])
    need = (minmax(df["Poverty Rate"])
            + minmax(-df["Median Household Income"])
            + minmax(df["Median Age"]))
    df["need_score"] = minmax(need)
    df["priority"] = w_gap * df["gap_score"] + w_need * df["need_score"]
    return df.sort_values("priority", ascending=False).reset_index(drop=True)


def main():
    acs = pd.read_csv("data/processed/acs_features.csv")
    cov = pd.read_csv("data/processed/coverage_by_county.csv")
    df = acs.merge(cov, on="GEO_ID", how="inner")
    assert len(df) == 67, f"merge produced {len(df)} rows, expected 67"

    ranked = score(df, W_GAP, W_NEED)
    ranked.to_csv("outputs/tables/priority_ranking.csv", index=False)
    print(f"Top 10 priority counties (W_GAP={W_GAP}, W_NEED={W_NEED}):")
    print(ranked[["NAME", "priority", "unserved_people"]].head(10).to_string(index=False))

    # --- weight sensitivity: does the top-10 hold up? ---
    rows = []
    for wg in [0.9, 0.7, 0.5, 0.3]:
        top10 = score(df, wg, 1 - wg).head(10)["NAME"].tolist()
        rows.append({"W_GAP": wg, "W_NEED": round(1 - wg, 1), "top10": ", ".join(top10)})
    pd.DataFrame(rows).to_csv("outputs/tables/weight_sensitivity.csv", index=False)
    print("\nwrote outputs/tables/{priority_ranking,weight_sensitivity}.csv")


if __name__ == "__main__":
    main()
