"""
05_visualize.py  —  Choropleth of priority score + supporting figures.

Outputs: outputs/figures/priority_choropleth.png

Needs the Census county boundary file in data/raw/ (cb_2023_us_county_500k).
"""
import geopandas as gpd
import matplotlib.pyplot as plt
import pandas as pd

BOUNDARIES = "data/raw/cb_2023_us_county_500k.shp"   # TODO: unzip the CB file here
RANKING = "outputs/tables/priority_ranking.csv"


def main():
    gdf = gpd.read_file(BOUNDARIES)
    gdf = gdf[gdf["STATEFP"] == "12"].copy()          # Florida only
    # CB files key counties by GEOIDFQ (formerly AFFGEOID), e.g. 0500000US12001
    gdf = gdf.rename(columns={"GEOIDFQ": "GEO_ID"})    # TODO: confirm attribute name

    ranking = pd.read_csv(RANKING)
    gdf = gdf.merge(ranking[["GEO_ID", "priority"]], on="GEO_ID", how="left")

    fig, ax = plt.subplots(figsize=(9, 9))
    gdf.plot(column="priority", cmap="OrRd", legend=True,
             edgecolor="white", linewidth=0.4, ax=ax,
             legend_kwds={"label": "Priority score (higher = greater need)"})
    ax.set_title("Florida mobile broadband investment priority by county")
    ax.axis("off")
    fig.savefig("outputs/figures/priority_choropleth.png", dpi=200, bbox_inches="tight")
    print("wrote outputs/figures/priority_choropleth.png")


if __name__ == "__main__":
    main()
