# Data sources & provenance

Fill the "Downloaded" column when you grab each file, and drop the raw file in
`data/raw/`. Keep file names and dates exact — this table is your reproducibility
record.

| # | Dataset | What it gives | Source / link | File / table IDs | Vintage | Downloaded |
|---|---------|---------------|---------------|------------------|---------|------------|
| 1 | Census ACS 5-Year | income, poverty, age, education, unemployment, renter, population | api.census.gov/data/2023/acs/acs5 (+ /subject) | B19013_001E, S1701_C03_001E, B01002_001E, S1501_C02_015E, S2301_C04_001E, B25003_001E/003E, B01003_001E | 2019–2023 | (auto via 01_pull_acs.py) |
| 2 | FCC mobile coverage | covered share per county (the gap backbone) | broadbandmap.fcc.gov/data-download → **Mobile** Broadband Summary by Geography Type | bdc_us_mobile_broadband_summary_by_geography_*.csv | as-of 2025-06-30 | ____ |
| 3 | FCC mobile raw (optional) | provider H3 hex coverage (sub-county / by tech) | broadbandmap.fcc.gov/data-download → By Provider | Shapefile/GeoPackage, H3 res 9 | 2025-06-30 | ____ |
| 4 | Existing towers (context) | tower locations | FCC ASR: fcc.gov/wireless/data/public-access-files-database-downloads | ASR weekly files | current | ____ |
| 5 | Ookla Open Data (validation) | measured mobile speeds | github.com/teamookla/ookla-open-data ; s3://ookla-open-data | performance_mobile_tiles (parquet, z16) | latest quarter | ____ |
| 6 | County boundaries | choropleth + spatial joins | census.gov cartographic boundary files | cb_2023_us_county_500k | 2023 | ____ |
| 7 | BEAD context (framing) | policy stakes / alignment check | broadband.commerce.fl.gov/pages/bead-program | FL Final Proposal | 2025–26 | ____ |

## Notes / gotchas
- ACS: detailed (B) and subject (S) variables are **separate API calls** — joined on county FIPS in 01_pull_acs.py.
- FCC: the file you want is **MOBILE**, not fixed. Confirm the `technology` column shows 4G LTE / 5G-NR, not Cable/Fiber.
- Filtering "Florida" by name catches *Florida Municipio* in Puerto Rico (FIPS 72). Filter on `geography_type == "County"` AND state FIPS **12**.
- HIFLD Cellular Towers ArcGIS Hub was deactivated 2025-08-26; use FCC ASR or the ICPSR/DataLumos archive, and note the undercount.
